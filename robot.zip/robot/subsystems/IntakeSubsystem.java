package frc.robot.subsystems;

import frc.robot.helpers.appendix;

import com.revrobotics.CANSparkMax;
import com.revrobotics.CANSparkLowLevel.MotorType;

import edu.wpi.first.wpilibj.Joystick;

public class IntakeSubsystem {
    Joystick gamePad = new Joystick(appendix.driveControllerID);

    CANSparkMax motorRoller_01 = new CANSparkMax(0, MotorType.kBrushless);
    CANSparkMax motorRoller_02 = new CANSparkMax(0, MotorType.kBrushless);

    public IntakeSubsystem() {
        motorRoller_02.follow(motorRoller_01);
    }

    public void teleopPeriodic() {
        motorRoller_01.set(1);
    }
}