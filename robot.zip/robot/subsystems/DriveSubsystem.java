package frc.robot.subsystems;

import frc.robot.helpers.appendix;

import com.revrobotics.CANSparkMax;
import com.revrobotics.CANSparkLowLevel.MotorType;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

public class DriveSubsystem {
    Joystick gamePad = new Joystick(0);

    private CANSparkMax motorLeft_01 = new CANSparkMax(0, MotorType.kBrushless);
    private CANSparkMax motorLeft_02 = new CANSparkMax(0, MotorType.kBrushless);
    private CANSparkMax motorRight_01 = new CANSparkMax(0, MotorType.kBrushless);
    private CANSparkMax motorRight_02 = new CANSparkMax(0, MotorType.kBrushless);

    DifferentialDrive driveBase = new DifferentialDrive(motorLeft_01, motorRight_01);

    private static double sensitivity1 = 0.45;
    private static double sensitivity2 = 0.35;

    private double currentRotationSpeed = sensitivity1;

    public DriveSubsystem() {
        motorLeft_02.follow(motorLeft_01);
        motorRight_02.follow(motorRight_01);
        driveBase.setSafetyEnabled(true);
    }

    public static double quadraticDrive(double inputAxis, double speedModifier) {
        double magnitude = Math.pow(inputAxis, 2) * speedModifier;
        return inputAxis < 0 ? -magnitude : magnitude;
    }

    public void teleopPeriodic() {
        double driveValue = gamePad.getRawAxis(appendix.axisLeftY);
        double rotationValue = gamePad.getRawAxis(appendix.axisLeftX);

        double driveSpeed = 0.8;

        if (gamePad.getRawButton(appendix.buttonY)) {
            driveSpeed = 1;
        }

        driveSpeed = gamePad.getRawButton(appendix.buttonX) ? driveSpeed * -1 : driveSpeed;

        driveBase.curvatureDrive(quadraticDrive(rotationValue, currentRotationSpeed), quadraticDrive(-driveValue, driveSpeed), true);
    }
}